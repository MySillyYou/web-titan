<template>
  <div>123</div>
</template>

<script lang='ts' setup>
import { ref } from 'vue'

</script>
<script lang='ts'>
export default {
  name: 'Home',
  inheritAttrs: true,
}
</script>

<style lang='scss' scoped>
div {
  background: red;
}
</style>