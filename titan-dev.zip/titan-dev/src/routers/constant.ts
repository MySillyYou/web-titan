export const Layout = () => import('@/layout/index.vue');
